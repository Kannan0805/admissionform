-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 29, 2020 at 01:08 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `velammal`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `user` varchar(30) DEFAULT NULL,
  `password` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`user`, `password`) VALUES
('admin', 'vitech');

-- --------------------------------------------------------

--
-- Table structure for table `vel`
--

CREATE TABLE `vel` (
  `fname` varchar(30) DEFAULT NULL,
  `lname` varchar(30) DEFAULT NULL,
  `dob` varchar(30) DEFAULT NULL,
  `email` varchar(40) DEFAULT NULL,
  `password` varchar(30) DEFAULT NULL,
  `cpassword` varchar(30) DEFAULT NULL,
  `num` varchar(20) DEFAULT NULL,
  `anum` varchar(20) DEFAULT NULL,
  `living` varchar(10) DEFAULT NULL,
  `pname` varchar(30) DEFAULT NULL,
  `poccu` varchar(30) DEFAULT NULL,
  `mtongue` varchar(30) DEFAULT NULL,
  `tenth` varchar(10) DEFAULT NULL,
  `address` varchar(70) DEFAULT NULL,
  `district` varchar(30) DEFAULT NULL,
  `state` varchar(30) DEFAULT NULL,
  `pincode` varchar(20) DEFAULT NULL,
  `religion` varchar(20) DEFAULT NULL,
  `registered` varchar(40) DEFAULT NULL,
  `choice` varchar(20) DEFAULT NULL,
  `fpre` varchar(20) DEFAULT NULL,
  `spre` varchar(20) DEFAULT NULL,
  `gender` varchar(20) DEFAULT NULL,
  `ref` varchar(30) DEFAULT NULL,
  `regno` varchar(30) DEFAULT NULL,
  `school` varchar(100) DEFAULT NULL,
  `grou` varchar(30) DEFAULT NULL,
  `vel` varchar(30) DEFAULT NULL,
  `bos` varchar(30) DEFAULT NULL,
  `mediu` varchar(30) DEFAULT NULL,
  `gro` varchar(30) DEFAULT NULL,
  `expected` varchar(30) DEFAULT NULL,
  `diploma` varchar(30) DEFAULT NULL,
  `mark` varchar(30) DEFAULT NULL,
  `pregno` varchar(30) DEFAULT NULL,
  `college` varchar(40) DEFAULT NULL,
  `dept` varchar(30) DEFAULT NULL,
  `doj` varchar(30) DEFAULT NULL,
  `med` varchar(30) DEFAULT NULL,
  `smat` varchar(30) DEFAULT NULL,
  `sphy` varchar(30) DEFAULT NULL,
  `sche` varchar(30) DEFAULT NULL,
  `cmat` varchar(30) DEFAULT NULL,
  `cphy` varchar(30) DEFAULT NULL,
  `cche` varchar(30) DEFAULT NULL,
  `amata` varchar(30) DEFAULT NULL,
  `amatb` varchar(30) DEFAULT NULL,
  `aphy` varchar(30) DEFAULT NULL,
  `apphy` varchar(30) DEFAULT NULL,
  `ache` varchar(30) DEFAULT NULL,
  `apche` varchar(30) DEFAULT NULL,
  `scutoff` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
